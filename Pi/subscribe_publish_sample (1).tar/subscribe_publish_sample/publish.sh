#!/bin/bash
cwd=/home/pi/sdk/sample_apps/subscribe_publish_sample
cd $cwd
./subscribe_publish_sample 2>./log/std.err
